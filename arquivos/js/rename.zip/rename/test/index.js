"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.test = void 0;
exports.test = () => require('./start.js')